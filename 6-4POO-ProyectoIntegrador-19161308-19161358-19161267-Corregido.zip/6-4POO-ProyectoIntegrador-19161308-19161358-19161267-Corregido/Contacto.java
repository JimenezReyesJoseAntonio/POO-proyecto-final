
import java.util.ArrayList;
public class Contacto{
    public String nombre;
    public String direccion;
    public String  numeros;
    public String correoElectronico;
    public static ArrayList<Telefono> telefonos;
    
    public Contacto(String nombre, String direccion, String correoElectronico,String numeros){
        this.nombre  = nombre;
        this.numeros = numeros;
        this.direccion = direccion;
        this.correoElectronico = correoElectronico;
    }
    
    public void setNombre(String nombre){
        this.nombre = nombre; 
    }

    public String getNombre(){
        return nombre;
    }


    public String getNumeros(){
        return numeros;
    }
    public void setDireccion(String direccion){
        this.direccion = direccion; 
    }

    public String getDireccion(){
        return direccion;
    }

    public void setCorreoElectronico(String correoElectronico){
        this.correoElectronico = correoElectronico; 
    }

    public String getCorreoElectronico(){
        return correoElectronico;
    }
    
    public void obtenerNumeros(ArrayList<Telefono>numerosTelefonicos){
     telefonos = numerosTelefonicos;
    }
    
    
    public String toString(){
        String str = "Nombre : " + getNombre() + "\n";
         
        str += "Correo electronico: " + getCorreoElectronico() + "\n";
        str += "Direccion: " + getDireccion() + "\n";
        str += numeros;
        return str;
    }
}
