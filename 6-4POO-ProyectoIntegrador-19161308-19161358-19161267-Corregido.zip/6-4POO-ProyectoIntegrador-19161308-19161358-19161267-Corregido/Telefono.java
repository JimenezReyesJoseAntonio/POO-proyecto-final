

public class Telefono
{
    private String numero;
    private String tipo;
    
    public Telefono(String numero, String tipo){
       this.numero = numero;
       this.tipo = tipo;
    }
    
    public void setNumero(String numero){
     this.numero = numero;
    }
    
    public String getNumero(){
     return numero;
    }
    
    public void setTipo(){
     this.tipo = tipo;
    }
    
    public String getTipo(){
     return tipo;
    }
    
    public String toString(){
     String s = "Telefonodetipo" + tipo + ":" + numero;
     return s;
    }
}
