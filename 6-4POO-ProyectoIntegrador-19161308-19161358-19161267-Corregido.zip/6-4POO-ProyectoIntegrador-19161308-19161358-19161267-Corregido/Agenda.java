import java.io.*;
import java.io.IOException;
import java.io.StreamCorruptedException;
import java.util.Scanner;
import java.util.InputMismatchException;
import javax.swing.JOptionPane;

public class Agenda{
    Scanner entrada = new Scanner(System.in);

    public void agregarContacto(Contacto contacto)throws IOException{
        File f = new File("agendaContactos.txt");
        FileWriter w;
        BufferedWriter bw;
        if(f.exists() && f.length() != 0){
            w = new FileWriter(f,true);
            bw = new BufferedWriter(w);
            bw.newLine();
            bw.write(contacto.nombre+"%"+contacto.correoElectronico+"%"+contacto.direccion+"%"+contacto.numeros);
        }else{
            w = new FileWriter(f);
            bw = new BufferedWriter(w);
            bw.write(contacto.nombre+"%"+contacto.correoElectronico+"%"+contacto.direccion+"%"+contacto.numeros);
        }

        bw.close();
        w.close();
    }

    public void eliminarContacto(String nombreContacto)throws FileNotFoundException, IOException {
        File f = new File("agendaContactos.txt");

        if(f.exists()){
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String linea;
            int numLineas = 0;
            while((linea = br.readLine()) != null){
                numLineas++;
            }
            String contactos[] = new String[numLineas];
            br.close();
            fr.close();
            br = new BufferedReader(fr = new FileReader(f));
            int i = 0;
            while((linea = br.readLine()) != null){
                contactos[i] = linea;
                i++;
            }
            br.close();
            fr.close();
            FileWriter fw = new FileWriter(f);
            BufferedWriter bw = new BufferedWriter(fw);
            boolean bandera = false;
            boolean primeraL = true;
            for(int j=0; j < contactos.length; j++){
                String l [] = contactos[j].split("%");
                if(l[0].equals(nombreContacto)){
                    bandera = true;
                    JOptionPane.showMessageDialog(null,"Contacto Eliminado" );

                } else{
                    if(primeraL == true){
                        bw.write(contactos[j]);
                        primeraL = false;
                    } else{
                        bw.newLine();
                        bw.write(contactos[j]);
                    }
                }
            }
            if(bandera == false){
                JOptionPane.showMessageDialog(null,"No se encontró el contacto");

            }
            bw.close();
            fw.close();
            if(numLineas == 1 && bandera == true){
                f.delete();
            }

        } else{
            JOptionPane.showMessageDialog(null,"No hay contactos existentes.");
        }

    }

    public Contacto buscar(String nombreContacto) throws FileNotFoundException, IOException{
        Contacto buscado = null;
        File f = new File("agendaContactos.txt");

        if(f.exists()){
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String linea;
            boolean aux = false;
            while((linea = br.readLine()) != null){
                String contacto [] = linea.split("%");
                if(contacto[0].equals(nombreContacto)){
                    aux = true;
                    Contacto c = new Contacto (contacto[0],contacto[1],
                            contacto[2],contacto[3]);
                    System.out.println("Persona encontrada: ");
                    buscado = c;
                    //System.out.print(c.toString());
                    System.out.println();
                }
            }
            if(aux == false){
                JOptionPane.showMessageDialog(null,"contacto no existente");
            }
        }else{
            JOptionPane.showMessageDialog(null,"Aun no hay una agenda");

        }
        return buscado;
    }

    public void mostrarContactos() throws FileNotFoundException, IOException{
        File f = new File("agendaContactos.txt");
        if(f.exists()){
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String linea;
            while((linea = br.readLine()) != null){
                String[] contacto = linea.split("%");
                Contacto c = new Contacto(contacto[0],contacto[1],
                        contacto[2],contacto[3]);
                System.out.println(c.toString());
                System.out.println("--------------------");
            }
        } else{
            
            JOptionPane.showMessageDialog(null,"Agenda Vacía");

        }
    }
    // valida si la opcion es un numero y no una letra para que no se pare el programa 
    public boolean validarOpcion(String opc){
        boolean aux;
        try{
            int op = Integer.parseInt(opc);
            return true;
        }catch(NumberFormatException ex){
            return false;
        } 
    }
}
