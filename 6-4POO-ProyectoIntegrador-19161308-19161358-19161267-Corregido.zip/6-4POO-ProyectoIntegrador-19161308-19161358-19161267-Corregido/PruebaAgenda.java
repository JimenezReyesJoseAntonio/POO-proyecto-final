import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.InputMismatchException;
import java.util.ArrayList;
import java.io.FileNotFoundException;
public class PruebaAgenda{
    public static String  menu(){
        String strmenu = "";
        strmenu += "******MENU PRINCIPAL******" + "\n";
        strmenu += "1: Agregar contacto" + "\n";
        strmenu += "2: Eliminar contacto" + "\n";
        strmenu += "3: Buscar un contacto" + "\n";
        strmenu += "4: Mostrar Todos Los Contactos"+"\n";
        strmenu += "5: Salir "; 

        return strmenu;

    }

    public static void main(String []args) throws Exception{
        ArrayList<Telefono> telefonos = new ArrayList<Telefono>();
        Scanner entrada = new Scanner(System.in);
        Agenda agenda = new Agenda();
        boolean salir = true;
        String opc;
        int opcion = 0 ;
        try{
            while(salir){
                opc = JOptionPane.showInputDialog(null, menu());
                
                if(agenda.validarOpcion(opc) == true){
                  opcion = Integer.parseInt(opc);
                }else{
                 opcion = 7;
                 JOptionPane.showMessageDialog(null, "No se permite en el menu letras ");

                }
                
                switch(opcion){
                    case 1:
                    boolean aux = true;
                    Contacto contacto;
                    String nombre, telefono, tipo,telefonosL, correoElectronico,domicilio;
                    telefonosL = "";
                    int respuesta;
                    nombre = JOptionPane.showInputDialog(null, "Ingrese el nombre ");
                    while(aux){
                        JOptionPane.showMessageDialog(null, "Agregar telefono");
                        telefono = JOptionPane.showInputDialog(null, "Ingrese su numero de telefono");
                        tipo = JOptionPane.showInputDialog(null, "Ingrese el tipo (personal/casa/trabajo)");
                        Telefono con = new Telefono(telefono, tipo);
                        telefonos.add(con);
                        respuesta = Integer.parseInt(JOptionPane.showInputDialog(null,"Desea agregar otro\n1.Si \n2.No "));

                        if(respuesta == 2){
                            aux = false;
                        }

                    }
                    // guarda en un array los numeros del contacto que valla agregando 
                    for(Telefono t: telefonos){
                        telefonosL += "-"+t.toString();
                    }
                    correoElectronico = JOptionPane.showInputDialog(null, "Ingrese su correo electronico");
                    domicilio = JOptionPane.showInputDialog(null, "Ingrese su domicilio ");
                    contacto = new Contacto(nombre,correoElectronico,domicilio,telefonosL);
                    agenda.agregarContacto(contacto);
                    contacto.obtenerNumeros(telefonos);

                    break;

                    //Eliminar Contacto Por Medio Del Nombre
                    case 2:
                    String deleteContact;
                    deleteContact = JOptionPane.showInputDialog(null, "Ingrese el contacto a eliminar");
                    agenda.eliminarContacto(deleteContact);
                    break;

                    //Buscar un contacto por medio del nombre
                    case 3:
                    Contacto encontrado;
                    String buscarContacto ;
                    buscarContacto = JOptionPane.showInputDialog(null, "Ingrese el contacto a buscar");
                    encontrado = agenda.buscar(buscarContacto);
                    if(encontrado != null){
                          System.out.println(encontrado.toString());
                    } 
                      
                
                    break;

                    //Mostrar o imprimir todos los contactos
                    case 4:                       
                    agenda.mostrarContactos();
                    break;

                    case 5:
                    salir = false;
                    break;

                    default:
                    System.out.println("Opcion no valida pruebe de nuevo");
                }

            }

        }catch(NumberFormatException ex){
          System.out.println("No se permiten letras");

        }catch(InputMismatchException er){
            System.err.println(er);
        }catch(FileNotFoundException f){
            System.err.printf("%nExcepcion: %s%n",f);
            System.err.printf("El fichero no se ha encontrado o no existe",f);
        }catch(IOException i){
            System.err.printf("%nExcepcion: %s%n",i);
            System.err.printf("Error en Entrada/Salida",i);
        }catch(Exception c){
            System.err.println(c);
            System.out.println("Error inesperado");
        }
    }
}